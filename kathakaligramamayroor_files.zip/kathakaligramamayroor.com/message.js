$('#butt').toggle(function(){
	$('#Videomsg').hide();
	$('#scollmsg').show();
	},
	
	function(){
		$('#scollmsg').hide();
		$('#Videomsg').show();
		}
	);
